<footer id="fh5co-footer" role="contentinfo">

		<div class="container">
			<div class="col-md-3 col-sm-9 col-sm-push-0 ">
				<h3>SOLO</h3>
				<p></p>
			</div>
			<div class="col-md-4 col-md-push-1 col-sm-9 col-sm-push-0 col-xs-9 col-xs-push-0">
				<h3>BSI GROUP</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>"></a></li>
					<li><a href="<?php echo base_url().'portfolio'?>"></a></li>
					<li><a href="<?php echo base_url().'portfolio'?>"></a></li>
				</ul>
				

			</div>
			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>INFORMASI Berita</h3>
				<ul class="float">
					<li><a href="<?php echo base_url().'portfolio'?>">solo</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">comeback</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">dating</a></li>
					<li><a href="<?php echo base_url().'portfolio'?>">portofolio</a></li>
				</ul>
			</div>

			<div class="col-md-2 col-md-push-1 col-sm-12 col-sm-push-0 col-xs-12 col-xs-push-0">
				<h3>Sosial Media</h3>
				<ul class="fh5co-social">
					<li><a href="#"><i class="icon-twitter"></i></a></li>
					<li><a href="#"><i class="icon-facebook"></i></a></li>
					<li><a href="#"><i class="icon-google-plus"></i></a></li>
					<li><a href="#"><i class="icon-instagram"></i></a></li>
				</ul>
			</div>


			<div class="col-md-12 fh5co-copyright text-center">
				<p>&copy; 2024 By Kpoppage.id</a>. All Rights Reserved.</p>
			</div>

		</div>
	</footer>
